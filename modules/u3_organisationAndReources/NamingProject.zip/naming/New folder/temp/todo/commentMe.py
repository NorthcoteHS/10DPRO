print('Welcome to the Circle Calculator!')

r = input('Enter a radius: ')
r = int(r)

area = 3.14 * r * r
print('The area is', area)

perimeter = 3.14 * r * 2
print('The perimeter is', perimeter)
